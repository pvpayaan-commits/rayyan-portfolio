# On-page SEO fixes — find & replace in `index.html`

I don't have write access to your GitHub repo, so here's exactly what to
change and paste in yourself. Each block below is a straight find → replace.

---

## 1. Title tag

**Find:**
```html
<title>Rayyan — Web Developer in Multan | Portfolio</title>
```

**Replace with:**
```html
<title>Affordable Website Design for Businesses & Schools in Multan, Pakistan | Rayyan</title>
```

Why: leads with the service + location people actually type into Google,
instead of leading with your name.

---

## 2. Meta description

**Find:**
```html
<meta name="description" content="Web developer in Multan building affordable, modern websites for schools, restaurants, hospitals & local businesses in Pakistan. WhatsApp support, fast delivery, payment after delivery.">
```

**Replace with:**
```html
<meta name="description" content="Get an affordable, modern website for your school, restaurant, clinic or business in Multan starting at Rs 10,000. Fast delivery, WhatsApp support, pay only after launch.">
```

Why: adds a concrete price anchor and a clear call-to-action, which tends to
lift click-through rate from search results.

---

## 3. Add a sitemap reference + canonical tag

**Add inside `<head>`, near the other meta tags:**
```html
<link rel="canonical" href="https://pvpayaan-commits.github.io/rayyan-portfolio/">
<link rel="sitemap" type="application/xml" title="Sitemap" href="/rayyan-portfolio/sitemap.xml">
```

---

## 4. Image alt text

Add descriptive `alt` attributes to every project thumbnail. Examples based
on your current project cards:

```html
<img src="assets/nishat-school.jpg" alt="Nishat Boys High School website homepage — admissions and gallery, designed by Rayyan">

<img src="assets/multan-metro.jpg" alt="Multan Metro Restaurant website — online menu, gallery and WhatsApp ordering">

<img src="assets/nishtar-hospital.jpg" alt="Nishtar Hospital website — doctor profiles, timings and appointment booking">

<img src="assets/lumiere-dental.jpg" alt="Lumière Dental Studio website — services, team bios and before/after gallery">
```

(Swap in your actual filenames/paths — I don't have the raw HTML source, so
match these to whatever `src` values you're currently using.)

---

## 5. Files to add to your repo root

Drop these two files (already generated) directly into the root of the
`rayyan-portfolio` repo, alongside `index.html`:

- `robots.txt`
- `sitemap.xml`

And paste `schema-snippet.html`'s contents into `index.html`'s `<head>`,
right before `</head>`.

---

## 6. After deploying

1. Go to [Google Search Console](https://search.google.com/search-console),
   add the property, verify ownership (HTML tag method works well with
   GitHub Pages), and submit `sitemap.xml`.
2. Create a **Google Business Profile** as a service-area business based in
   Multan — this is what actually surfaces you for "web developer near me"
   searches, separate from the website itself.
3. Once you get a custom domain, update every URL in `sitemap.xml`,
   `robots.txt`, the canonical tag, and the JSON-LD `url`/`image` fields to
   match the new domain.
